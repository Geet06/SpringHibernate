package com.miniau.firsthibernate;

import java.util.Set;
import java.util.HashSet;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.miniau.firsthibernate.model.Address;
import com.miniau.firsthibernate.dao.PersonDao;
import com.miniau.firsthibernate.model.test;
import com.miniau.firsthibernate.model.phone;

public class FirstHibernate {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		PersonDao persondao= context.getBean(PersonDao.class);
		
		test a=new test();
		a.setEname("Geet");
		a.setDpt("HR");
		a.setAge(21);
		
		Address address=new Address();
		address.setStreetno("11");
		address.setCity("Bathinda");
		
		phone p1=new phone();
		phone p2=new phone();
		p1.setNumber("9855");
		p2.setNumber("0000");
		Set<phone> phones =  new HashSet<phone>();
		
		phones.add(p2);
		phones.add(p1);
		
		a.setPhn(phones);		
		a.setAddress(address);

		persondao.save(a);
		
	}

}
