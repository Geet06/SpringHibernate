package com.miniau.firsthibernate.dao;

import java.util.List;
import com.miniau.firsthibernate.model.test;

public interface PersonDao {

	public void save(test a);
	public List<test> getAllPerson();
	public boolean delete(int empid);
	public boolean update(test a);
	
}