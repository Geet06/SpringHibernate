package com.miniau.firsthibernate.dao.impl;

import java.util.List;
import org.hibernate.*;

import com.miniau.firsthibernate.dao.PersonDao;
import com.miniau.firsthibernate.model.test;

public class daoimpl implements PersonDao {
	
	private SessionFactory sessionfactory;
	
	public void setSf(SessionFactory sessionfactory) {
		this.sessionfactory = sessionfactory;
	}

	public void save(test a) {
		Session session=this.sessionfactory.openSession();
		Transaction trns=session.beginTransaction();
		session.persist(a);
		trns.commit();
		session.close();
	}
	public List<test> getAllPerson() {
		Session session=this.sessionfactory.openSession();
		@SuppressWarnings("unchecked")
		List<test> person=session.createQuery("from test").list();
		session.close();
		return person;
	}

	public boolean delete(int empid) {
		Session session=this.sessionfactory.openSession();
		Transaction trns=session.beginTransaction();
		test a=(test)session.load(daoimpl.class,empid);
		if(a!=null) {
			session.delete(a);
		}
		trns.commit();
		session.close();
		return true;
	}

	public boolean update(test a) {
		Session session=this.sessionfactory.openSession();
		Transaction trns=session.beginTransaction();
		session.saveOrUpdate(a);
		trns.commit();
		session.close();
		return true;
	}
	

}
