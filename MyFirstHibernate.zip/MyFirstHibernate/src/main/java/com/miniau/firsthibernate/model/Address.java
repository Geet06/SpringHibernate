package com.miniau.firsthibernate.model;

import java.security.Timestamp;
import javax.persistence.*;

@Entity
@Table(name="address")
public class Address {

		public Address() {
		super();		
	}
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="getid")
		private int getid;
		
		@Column(name="city")
		private String city;
		
		@Column(name="streetno")
		private String streetno;
		
		@Column(name="cdate")
		private Timestamp cdate;
		
		@Column(name="udate")
		private Timestamp udate;
		
		public int getGetid() {
			return getid;
		}
		public void setGetid(int getid) {
			this.getid = getid;
		}
		
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		
		public String getStreetno() {
			return streetno;
		}
		public void setStreetno(String streetno) {
			this.streetno = streetno;
		}
		
		public Timestamp getCdate() {
			return cdate;
		}
		public void setCdate(Timestamp cdate) {
			this.cdate = cdate;
		}
		
		public Timestamp getUdate() {
			return udate;
		}
		public void setUdate(Timestamp udate) {
			this.udate = udate;
		}
		@Override
		public String toString() {
			return "Address [getid=" + getid + ", streetno=" + streetno + ", city=" + city + ", cdate=" + cdate
					+ ", udate=" + udate + "]";
		}
		
			
}
