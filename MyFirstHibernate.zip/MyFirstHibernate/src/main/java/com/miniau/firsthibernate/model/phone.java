package com.miniau.firsthibernate.model;

import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.JoinColumn;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;


@Entity
@Table(name="phone")
public class phone {
	
	public phone() {
		// TODO Auto-generated constructor stub
		}
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="number")
	private String number;
	
	@ManyToOne()
	@JoinColumn(name="person_id")
	private test a;
	
	public test getT() {
		return a;
	}
	public void setT(test a) {
		this.a = a;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	
	@Override
	public String toString() {
		return "phone [id=" + id + ", number=" + number + ", a=" + a + "]";
	}
}
	
