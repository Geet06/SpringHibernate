package com.miniau.firsthibernate.model;

import java.security.Timestamp;
import java.util.Set;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType; 
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
@Table(name="empl")
public class test {
		
	public test()
	{
		super();
	}
	@Id
	@Column(name="empid")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int empid;
	
	@Column(name="ename")
	private String ename;
	
	@Column(name="dpt")
	private String dpt;
	
	@Column(name="age")
	private int age;
	
	@Column(name="cdate")
	private Timestamp cdate;
	
	@Column(name="udate")
	private Timestamp udate;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_id")
	private Address address;
	
	@OneToMany(mappedBy="test")
	private Set<phone> phn;
		
	public Set<phone> getPhn() {
		return phn;
	}
	public void setPhn(Set<phone> phn) {
		this.phn = phn;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getDpt() {
		return dpt;
	}
	public void setDpt(String dpt) {
		this.dpt = dpt;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Timestamp getCdate() {
		return cdate;
	}
	public void setCdate(Timestamp cdate) {
		this.cdate = cdate;
	}
	public Timestamp getUdate() {
		return udate;
	}
	public void setUdate(Timestamp udate) {
		this.udate = udate;
	}
	@Override
	public String toString() {
		return "test [empid=" + empid + ", ename=" + ename + ", dpt=" + dpt + ", age=" + age + ", cdate=" + cdate
				+ ", udate=" + udate + ", address=" + address + ", phn=" + phn + "]";
	}	

}
